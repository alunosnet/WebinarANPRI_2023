using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMove : MonoBehaviour
{
    PlayerInput _input;
    [SerializeField] float VelocidadeAndar = 3;
    [SerializeField] float VelocidadeRodar = 50;
    [SerializeField] float VelocidadeSalto = 5;
    CharacterController _characterController;
    Vector3 velocidade;
    Animator _animator;
    [SerializeField] bool LookWithMouse = true;
    // Start is called before the first frame update
    void Start()
    {
        _characterController=GetComponent<CharacterController>();
        _input = GetComponent<PlayerInput>();
        _animator = GetComponentInChildren<Animator>();
        if (LookWithMouse )
        {
            Cursor.lockState = CursorLockMode.Locked;
        }
    }

    // Update is called once per frame
    void Update()
    {
        float horizontal;
        if(LookWithMouse)
        {
            horizontal = _input.actions["Look"].ReadValue<Vector2>().x;
        }
        else
        {
            horizontal = _input.actions["Move"].ReadValue<Vector2>().x;
        }
        float vertical = _input.actions["Move"].ReadValue<Vector2>().y;
        bool jump = _input.actions["Jump"].WasPressedThisFrame();
        bool run = _input.actions["Run"].IsPressed();

        //rodar
        transform.Rotate(transform.up * horizontal * VelocidadeRodar * Time.deltaTime);

        if (run)
        {
            vertical *= 2;
        }

        Vector3 movimento = transform.forward * vertical * VelocidadeAndar * Time.deltaTime;

        _characterController.Move(movimento);

        _animator.SetFloat("velocidade", vertical);

        if (jump)
        {
            Debug.Log("Salta");
            velocidade.y = Mathf.Sqrt(VelocidadeSalto * Physics.gravity.y);
            _animator.SetTrigger("saltou");
        }

        velocidade += Physics.gravity * Time.deltaTime;
        _characterController.Move(velocidade * Time.deltaTime);
    }
}
