using System.Collections;
using System.Collections.Generic;
using UnityEngine;
/// <summary>
/// Script para estar nos objetos que tiram vida
/// </summary>
public class TiraVida : MonoBehaviour
{
    public int ValorTiraVida = 10;
    public float IntervaloPerderVida = 3;
    float _proximoIntervalo = 0;

    public void ProcessaColisao(GameObject go)
    {
        if (Time.time < _proximoIntervalo) return;
        var vida = go.GetComponent<Vida>();
        if (vida != null)
        {
            vida.PerdeVida(ValorTiraVida);
            _proximoIntervalo = Time.time + IntervaloPerderVida;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        //Quando a colis�o ocorre
        ProcessaColisao(collision.gameObject);
    }
    private void OnCollisionStay(Collision collision)
    {
        //Enquanto a colis�o ocorre
        ProcessaColisao(collision.gameObject);
    }
    private void OnCollisionExit(Collision collision)
    {
        //Colis�o terminou
    }
    private void OnTriggerEnter(Collider other)
    {
        //Colis�o corre com um trigger
        ProcessaColisao(other.gameObject);
    }
    private void OnTriggerStay(Collider other)
    {
        //colis�o est� ocorrer com um trigger
        ProcessaColisao(other.gameObject);
    }
    private void OnTriggerExit(Collider other)
    {
        //colis�o com o trigger terminou
    }
}
