using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Atirar : MonoBehaviour
{
    [SerializeField] GameObject Objeto;
    [SerializeField] Transform PontoAtirar;
    [SerializeField] float ForcaAtirar = 100;
    [SerializeField] float IntervaloAtirar = 0.5f;
    [SerializeField] string nome_trigger;
    [SerializeField] float IntervaloAnimacao = 0.3f;
    public bool Atirou = false;
    Animator _animator;

    // Start is called before the first frame update
    void Start()
    {
        _animator=transform.GetComponentInChildren<Animator>();
    }

    void Update()
    {
        
        if (Time.timeScale == 0) return;
        if (Input.GetButtonDown("Fire1") && Atirou==false)
        {

            Atirou = true;
            _animator.SetTrigger(nome_trigger);
            Invoke(nameof(AtirarObjeto), IntervaloAnimacao);
        }
        
    }
    public void AtirarObjeto()
    {
        
        var obj = Instantiate(Objeto,PontoAtirar.position,Quaternion.identity);
        obj.GetComponent<Rigidbody>().AddForce(transform.forward * ForcaAtirar);

        Destroy(obj, 5);
        Atirou = false;

    }
}
