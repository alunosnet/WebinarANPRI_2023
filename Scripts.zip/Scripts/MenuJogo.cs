using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuJogo : MonoBehaviour
{
    public GameObject PanelMenuJogo;
    GameObject _player;
    // Start is called before the first frame update
    void Start()
    {
        _player =FindObjectOfType<PlayerMove>().gameObject;
        ContinuarJogo();
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetButtonDown("Cancel"))
        {
            if (PanelMenuJogo.activeSelf)
            {
                ContinuarJogo();
            }
            else
            {
                PausarJogo();
            }
        }
    }
    public void ContinuarJogo()
    {
        Cursor.lockState = CursorLockMode.Locked;
        PanelMenuJogo.SetActive(false);
        Time.timeScale = 1.0f;
    }
    public void PausarJogo()
    {
        Cursor.lockState = CursorLockMode.None;
        PanelMenuJogo.SetActive(true);
        Time.timeScale = 0;
    }
    public void Terminar()
    {
        Time.timeScale = 1;
        SceneManager.LoadScene("menu_principal");
        
    }
    
   
}
