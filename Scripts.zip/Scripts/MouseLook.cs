using Cinemachine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Windows;

public class MouseLook : MonoBehaviour
{
    [SerializeField] float MouseSensitivityY = 5f;
    [SerializeField] float SmoothDampY = 0.2f;
    [SerializeField]
    [Tooltip("Altura min�ma da camera")]
    float minCameraY = 0.5f;
    [SerializeField]
    [Tooltip("Altura m�xima da camera")]
    float maxCameraY = 5f;
    PlayerInput _input;
    CinemachineVirtualCamera _cm;
    CinemachineTransposer _tp;

    // Start is called before the first frame update
    void Start()
    {
        //esconder e bloquear
        Cursor.lockState = CursorLockMode.Locked;
        _cm = FindObjectOfType<CinemachineVirtualCamera>();
        _tp=_cm.GetCinemachineComponent<CinemachineTransposer>();
        _input = GetComponent<PlayerInput>();
    }

    // Update is called once per frame
    void Update()
    {
        if (Time.timeScale == 0) return;

        float mouseY = _input.actions["Look"].ReadValue<Vector2>().y;
        mouseY = mouseY * MouseSensitivityY*Time.deltaTime;
        _tp.m_FollowOffset.y = Mathf.SmoothStep(_tp.m_FollowOffset.y, _tp.m_FollowOffset.y + mouseY, SmoothDampY);
        _tp.m_FollowOffset.y=Mathf.Clamp(_tp.m_FollowOffset.y,minCameraY, maxCameraY);
    }
}
